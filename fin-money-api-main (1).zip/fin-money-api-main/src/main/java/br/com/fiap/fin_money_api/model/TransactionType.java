package br.com.fiap.fin_money_api.model;

public enum TransactionType {
    INCOME, EXPENSE

}
